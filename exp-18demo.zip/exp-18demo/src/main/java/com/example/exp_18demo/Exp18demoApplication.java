package com.example.exp_18demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exp18demoApplication {

	public static void main(String[] args) {
		SpringApplication.run(Exp18demoApplication.class, args);
	}

}
