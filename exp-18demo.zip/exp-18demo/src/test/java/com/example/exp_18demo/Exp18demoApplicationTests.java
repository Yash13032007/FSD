package com.example.exp_18demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exp18demoApplicationTests {

	@Test
	void contextLoads() {
	}

}
